# Çevrimdışı Sınav APK

1. GitHub'da yeni bir depo açın, bu klasörün içeriğini (www, package.json, capacitor.config.json, .github ...) olduğu gibi yükleyin.
2. Depoda Actions > "APK derle" > Run workflow. 3-5 dk sürer.
3. Bittiğinde çalıştırmanın altındaki Artifacts > sinav-offline-apk dosyasını indirin, zip'ten app-debug.apk çıkar.
4. Telefona atıp açın (bilinmeyen kaynaklardan kuruluma izin gerekir). Kamera izni sorulunca verin.

Notlar
- Uygulama tamamen internetsiz çalışır; veri telefondaki uygulamada saklanır. Uygulamayı silmeden önce "Yedek indir" kullanın.
- Canlı kamera okuma APK içinde çalışır (https://localhost bağlamı), file:// sorunu yoktur.
- CSV ve yedek dosyaları "Paylaş" penceresiyle kaydedilir (Drive, WhatsApp, Dosyalar vb.).
- Evrak yazdırma (window.print) Android WebView'da çalışmaz: toplu evrakı bilgisayardan, sinav-offline.html ile PDF olarak alın.
- Sesli okuma kaldırıldı.
